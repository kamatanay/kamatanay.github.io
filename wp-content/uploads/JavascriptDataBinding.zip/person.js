var person = {};
person.firstName = '';
person.lastName = '';
person.age = '';
person.country = '';
