
	function initializeFormBinding()
	{
		var formElements = document.getElementsByTagName('input');
		$A(formElements).each(function(formElement)
					{
						Element.extend(formElement);
						initializeFormElement(formElement);
					});
	}

	function initializeFormElement(formElement)
	{
		if (!(formElementHasObjectAttribute(formElement) && formElementHasPropertyAttribute(formElement)))
			return;
		var objectName = getAttributeValue(formElement,'object');
		var propertyName = getAttributeValue(formElement,'property');
		window.eval('formElement.value = '+objectName+'.'+propertyName);
		window.eval('formElement.onchange=function(){ '+objectName+'.'+propertyName+' = formElement.value; }');
	}

	function formElementHasObjectAttribute(formElement)
	{
		return getAttributeValue(formElement,'object')!=null;
	}

	function formElementHasPropertyAttribute(formElement)
	{
		return getAttributeValue(formElement,'property')!=null;
	}

	function getAttributeValue(element, attributeName)
	{
		return element.readAttribute(attributeName);
	}